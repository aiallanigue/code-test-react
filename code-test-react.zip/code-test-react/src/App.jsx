import React, { useState, useRef, useCallback } from 'react';
import {
  useInfiniteQuery,
  QueryClient,
  QueryClientProvider,
} from '@tanstack/react-query';
import SpaceXLaunches from './SpaceXLaunches';

const fetchLaunches = async ({ pageParam = 1 }) => {
  const response = await fetch(
    `https://api.spacexdata.com/v3/launches?limit=10&offset=${
      (pageParam - 1) * 10
    }`
  );
  return response.json();
};

export default function App() {
  const [search, setSearch] = useState('');
  const observer = useRef();

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading } =
    useInfiniteQuery({
      queryKey: ['launches'],
      queryFn: fetchLaunches,
      getNextPageParam: lastPage =>
        lastPage.length === 10 ? lastPage.length + 1 : undefined,
      staleTime: 1000 * 60 * 5,
    });

  const lastLaunchRef = useCallback(
    node => {
      if (isFetchingNextPage) return;
      if (observer.current) observer.current.disconnect();
      observer.current = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting && hasNextPage) {
          fetchNextPage();
        }
      });
      if (node) observer.current.observe(node);
    },
    [isFetchingNextPage, hasNextPage, fetchNextPage]
  );

  const filteredData = data?.pages
    .flat()
    .filter(launch =>
      launch.mission_name.toLowerCase().includes(search.toLowerCase())
    );

  return (
    <div className='p-4 max-w-xl mx-auto'>
      <QueryClientProvider client={queryClient}>
        <div className='App'>
          <h1 className='text-center text-2xl font-bold mb-4'>
            SpaceX Launches
          </h1>
          <SpaceXLaunches />
        </div>
      </QueryClientProvider>
      <input
        type='text'
        placeholder='Search Mission Name'
        className='mb-4 w-full p-2 border rounded'
        value={search}
        onChange={e => setSearch(e.target.value)}
      />
      {isLoading ? (
        <p className='text-center'>Loading launches...</p>
      ) : (
        <div className='space-y-4'>
          {filteredData.length > 0 ? (
            filteredData.map((launch, index) => (
              <div
                key={launch.flight_number}
                className='border p-4 rounded-lg shadow'
                ref={index === filteredData.length - 1 ? lastLaunchRef : null}
              >
                <h2 className='text-lg font-bold'>{launch.mission_name}</h2>
                <p>Launch Year: {launch.launch_year}</p>
                <p>Rocket: {launch.rocket.rocket_name}</p>
              </div>
            ))
          ) : (
            <p className='text-center'>No matching launches found.</p>
          )}
          {isFetchingNextPage && (
            <p className='text-center'>Loading more launches...</p>
          )}
          {!hasNextPage && (
            <p className='text-center mt-4'>No more launches to load.</p>
          )}
        </div>
      )}
    </div>
  );
}
